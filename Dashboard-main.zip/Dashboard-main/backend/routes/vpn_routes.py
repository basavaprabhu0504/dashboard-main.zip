from flask import Blueprint, jsonify, request
from services.vpn_service import vpn_service

vpn_bp = Blueprint("vpn", __name__)

@vpn_bp.route("/api/status", methods=["GET"])
def get_status():
    status = vpn_service.get_status()
    return jsonify(status), 200

@vpn_bp.route("/api/classical/start", methods=["POST"])
def start_classical_vpn():
    res = vpn_service.start_classical()
    code = 200 if res.get("success") else 502
    return jsonify(res), code

@vpn_bp.route("/api/classical/stop", methods=["POST"])
def stop_classical_vpn():
    res = vpn_service.stop_classical()
    return jsonify(res), 200 if res.get("success") else 502

@vpn_bp.route("/api/chat/start", methods=["POST"])
def start_chat_app():
    data = request.get_json(silent=True) or {}
    client_msg = data.get("message", "Hello from Client")
    res = vpn_service.start_chat(client_message=client_msg)
    return jsonify(res), 200
