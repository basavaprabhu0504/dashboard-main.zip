import base64
import datetime
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from dotenv import load_dotenv
from services.ssh_service import ssh_service

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))


class AgentRequestError(Exception):
    """A failure returned by, or while reaching, a QVPN Flask agent."""


class VPNService:
    def __init__(self):
        self.server_agent_url = os.getenv("QVPN_SERVER_AGENT_URL", "http://192.168.56.102:8000").rstrip("/")
        self.client_agent_url = os.getenv("QVPN_CLIENT_AGENT_URL", "http://192.168.56.101:8000").rstrip("/")
        self.agent_timeout = float(os.getenv("QVPN_AGENT_TIMEOUT_SECONDS", "8"))
        self.server_tunnel_ip = os.getenv("SERVER_TUNNEL_IP", "10.8.0.1")
        self.client_tunnel_ip = os.getenv("CLIENT_TUNNEL_IP", "10.8.0.2")
        self.start_time = None

    def _agent_url(self, agent, path):
        base_url = self.server_agent_url if agent == "server" else self.client_agent_url
        return f"{base_url}{path}"

    def _request_agent(self, agent, path, method="GET"):
        request = Request(
            self._agent_url(agent, path),
            method=method,
            headers={"Accept": "application/json"},
        )
        try:
            with urlopen(request, timeout=self.agent_timeout) as response:
                raw_body = response.read().decode("utf-8")
        except HTTPError as error:
            body = error.read().decode("utf-8", errors="replace")
            try:
                message = json.loads(body).get("message") or json.loads(body).get("error")
            except json.JSONDecodeError:
                message = None
            raise AgentRequestError(message or f"QVPN {agent.title()} Agent returned HTTP {error.code}.") from error
        except URLError as error:
            raise AgentRequestError(f"QVPN {agent.title()} Agent is unreachable.") from error
        except TimeoutError as error:
            raise AgentRequestError(f"QVPN {agent.title()} Agent did not respond in time.") from error

        try:
            return json.loads(raw_body) if raw_body else {}
        except json.JSONDecodeError as error:
            raise AgentRequestError(f"QVPN {agent.title()} Agent returned invalid JSON.") from error

    @staticmethod
    def _is_successful(response):
        return isinstance(response, dict) and response.get("success") is True

    def _agent_host(self, agent):
        return urlparse(self.server_agent_url if agent == "server" else self.client_agent_url).hostname

    def get_status(self):
        # Each dashboard status request checks both agent health and actual VPN state.
        agent_status = {}
        vpn_status = {}
        errors = []
        checks = [(agent, "health", "/status") for agent in ("server", "client")]
        checks += [(agent, "vpn", "/vpn/status") for agent in ("server", "client")]
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = {executor.submit(self._request_agent, agent, path): (agent, check_type) for agent, check_type, path in checks}
            for future in as_completed(futures):
                agent, check_type = futures[future]
                try:
                    if check_type == "health":
                        agent_status[agent] = future.result()
                    else:
                        vpn_status[agent] = future.result()
                except AgentRequestError as error:
                    errors.append(error.args[0])

        server_active = vpn_status.get("server", {}).get("active") is True
        client_active = vpn_status.get("client", {}).get("active") is True
        status_unavailable = "server" not in vpn_status or "client" not in vpn_status
        if status_unavailable:
            vpn_state = "STATUS_UNKNOWN"
        elif server_active and client_active:
            vpn_state = "CONNECTED"
        elif server_active or client_active:
            vpn_state = "PARTIAL_CONNECTION"
        else:
            vpn_state = "DISCONNECTED"

        if vpn_state == "CONNECTED" and self.start_time is None:
            self.start_time = datetime.datetime.now()
        elif vpn_state != "CONNECTED":
            self.start_time = None

        uptime = "00:00:00"
        if self.start_time:
            elapsed = int((datetime.datetime.now() - self.start_time).total_seconds())
            hours, remainder = divmod(elapsed, 3600)
            minutes, seconds = divmod(remainder, 60)
            uptime = f"{hours:02d}:{minutes:02d}:{seconds:02d}"

        return {
            "serverOnline": "server" in agent_status,
            "clientOnline": "client" in agent_status,
            "serverActive": server_active,
            "clientActive": client_active,
            "vpnRunning": server_active and client_active,
            "vpnState": vpn_state,
            "server": vpn_status.get("server"),
            "client": vpn_status.get("client"),
            "service": vpn_status.get("server", {}).get("service") or vpn_status.get("client", {}).get("service"),
            "serverHost": self._agent_host("server"),
            "clientHost": self._agent_host("client"),
            "tunnelIP": self.server_tunnel_ip if server_active else "Unknown",
            "connectedClient": self.client_tunnel_ip if client_active else "Unknown",
            "cipher": "Not reported by agent",
            "uptime": uptime,
            "errors": list(dict.fromkeys(errors)),
        }

    def start_classical(self):
        try:
            server_response = self._request_agent("server", "/vpn/start/classical", method="POST")
            if not self._is_successful(server_response):
                return {"success": False, "message": server_response.get("message", "Unable to start QVPN Server Agent.")}
        except AgentRequestError as error:
            return {"success": False, "message": f"Unable to start QVPN server: {error}"}

        try:
            client_response = self._request_agent("client", "/vpn/start/classical", method="POST")
            if not self._is_successful(client_response):
                raise AgentRequestError(client_response.get("message", "Unable to start QVPN Client Agent."))
        except AgentRequestError as error:
            rollback_error = None
            try:
                rollback_response = self._request_agent("server", "/vpn/stop/classical", method="POST")
                if not self._is_successful(rollback_response):
                    rollback_error = rollback_response.get("message", "Server rollback was rejected.")
            except AgentRequestError as rollback_failure:
                rollback_error = str(rollback_failure)
            message = f"VPN startup incomplete. Server started successfully, but the client could not connect. A rollback was attempted. Client error: {error}"
            if rollback_error:
                message += f" Rollback failed: {rollback_error}"
            return {"success": False, "message": message, "status": self.get_status()}

        return {"success": True, "message": "Classical VPN start requests completed.", "status": self.get_status()}

    def stop_classical(self):
        failures = []
        for agent in ("client", "server"):
            try:
                response = self._request_agent(agent, "/vpn/stop/classical", method="POST")
                if not self._is_successful(response):
                    failures.append(f"{agent.title()}: {response.get('message', 'stop request was rejected.')}")
            except AgentRequestError as error:
                failures.append(f"{agent.title()}: {error}")

        status = self.get_status()
        if failures:
            return {"success": False, "message": f"VPN cleanup was incomplete. {' '.join(failures)}", "status": status}
        return {"success": True, "message": "Classical VPN stop requests completed.", "status": status}

    def start_chat(self, client_message="Hello from Client"):
        """Keep the existing SSH chat feature, but never fabricate a tunnel response."""
        status = self.get_status()
        if not status["vpnRunning"]:
            return {"success": False, "message": "Classical VPN is stopped or its status is unknown. Start and verify the tunnel before sending a message.", "clientMessage": client_message, "serverResponse": "", "terminalLogs": ["[SYSTEM] VPN connection is not verified active."]}

        server_ip = self.server_tunnel_ip
        server_script = (
            "import socket\n"
            "s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)\n"
            "s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)\n"
            "s.bind(('0.0.0.0', 9999))\n"
            "s.listen(1)\n"
            "conn, addr = s.accept()\n"
            "msg = conn.recv(1024).decode()\n"
            f'reply = "ACK from OpenVPN Server ({server_ip}): Hello! Received \'" + msg + "\' over encrypted VPN tunnel (tun0)"\n'
            "conn.sendall(reply.encode())\n"
            "conn.close()\n"
            "s.close()\n"
        )
        client_script = (
            "import socket, time\n"
            "time.sleep(0.5)\n"
            "s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)\n"
            "s.settimeout(5)\n"
            "try:\n"
            f"    s.connect(('{server_ip}', 9999))\n"
            f"    s.sendall({repr(client_message.encode('utf-8'))})\n"
            "    print('RECV: ' + s.recv(1024).decode())\n"
            "except Exception as e:\n"
            "    print('ERROR: ' + str(e))\n"
            "finally:\n"
            "    s.close()\n"
        )
        server_b64 = base64.b64encode(server_script.encode("utf-8")).decode("utf-8")
        client_b64 = base64.b64encode(client_script.encode("utf-8")).decode("utf-8")
        ssh_service.execute_on_server(f"python3 -c \"import base64; exec(base64.b64decode('{server_b64}'))\" > /dev/null 2>&1 &", timeout=1)
        client_output, client_error, client_code = ssh_service.execute_on_client(f"python3 -c \"import base64; exec(base64.b64decode('{client_b64}'))\"", timeout=7)
        if client_code == 0 and "RECV:" in client_output:
            response_text = client_output.split("RECV:", 1)[1].strip()
            return {"success": True, "message": "Client sent a message and received a response over the VPN tunnel.", "clientMessage": client_message, "serverResponse": response_text, "terminalLogs": [f"[CLIENT -> SERVER] Sent: \"{client_message}\"", f"[CLIENT] Received Response: \"{response_text}\""]}
        return {"success": False, "message": "Socket chat could not be completed over the verified VPN tunnel.", "clientMessage": client_message, "serverResponse": "", "terminalLogs": [f"[CLIENT] Socket chat failed: {client_error or client_output or 'no response'}"]}


vpn_service = VPNService()
