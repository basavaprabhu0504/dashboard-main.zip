const API_BASE = import.meta.env.VITE_DASHBOARD_API_BASE || '/api';
const REQUEST_TIMEOUT_MS = Number(import.meta.env.VITE_DASHBOARD_REQUEST_TIMEOUT_MS) || 10000;

class QvpnRequestError extends Error {
  constructor(message, cause) {
    super(message);
    this.name = 'QvpnRequestError';
    this.cause = cause;
  }
}

async function request(path, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: { Accept: 'application/json', ...options.headers },
      signal: controller.signal,
    });
    const body = await response.text();
    let data;
    try {
      data = body ? JSON.parse(body) : {};
    } catch {
      throw new QvpnRequestError('The dashboard backend returned an invalid response.');
    }
    if (!response.ok) throw new QvpnRequestError(data.message || data.error || `Dashboard backend returned HTTP ${response.status}.`);
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new QvpnRequestError('The dashboard backend did not respond in time.');
    if (error instanceof QvpnRequestError) throw error;
    throw new QvpnRequestError('Unable to contact the dashboard backend.', error);
  } finally {
    clearTimeout(timeout);
  }
}

function ensureSuccessful(data, action) {
  if (data?.success !== true) throw new QvpnRequestError(data?.message || `Unable to ${action} Classical VPN.`);
  return data;
}

function summaryFromDashboard(status) {
  return {
    server: status.server || null,
    client: status.client || null,
    serverActive: status.serverActive === true,
    clientActive: status.clientActive === true,
    state: status.vpnState || 'STATUS_UNKNOWN',
    errors: status.errors || [],
    serverOnline: status.serverOnline === true,
    clientOnline: status.clientOnline === true,
    serverHost: status.serverHost,
    clientHost: status.clientHost,
    service: status.service || null,
  };
}

export async function getVpnStatusSummary() {
  return summaryFromDashboard(await request('/status'));
}

export async function getAgentAvailability() {
  const status = await getVpnStatusSummary();
  return { serverOnline: status.serverOnline, clientOnline: status.clientOnline };
}

// These remain reusable status functions, but are routed through the dashboard backend.
export async function getServerStatus() { return (await getVpnStatusSummary()).server; }
export async function getClientStatus() { return (await getVpnStatusSummary()).client; }

export async function startClassicalVPN() {
  console.info('Requesting Classical VPN startup from dashboard backend.');
  const response = ensureSuccessful(await request('/classical/start', { method: 'POST' }), 'start');
  return { ...response, status: summaryFromDashboard(response.status || await request('/status')) };
}

export async function stopClassicalVPN() {
  console.info('Requesting Classical VPN shutdown from dashboard backend.');
  const response = ensureSuccessful(await request('/classical/stop', { method: 'POST' }), 'stop');
  return { ...response, status: summaryFromDashboard(response.status || await request('/status')) };
}
