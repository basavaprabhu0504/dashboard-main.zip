const BASE_URL = '/api';

export const api = {
  async get(path) {
    try {
      const response = await fetch(`${BASE_URL}${path}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.warn(`GET ${path} failed, backend offline or unreachable:`, error.message);
      return null;
    }
  },

  async post(path, payload = {}) {
    try {
      const response = await fetch(`${BASE_URL}${path}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      return { ok: response.ok, status: response.status, data };
    } catch (error) {
      console.warn(`POST ${path} failed:`, error.message);
      return { ok: false, error: error.message };
    }
  },
};
