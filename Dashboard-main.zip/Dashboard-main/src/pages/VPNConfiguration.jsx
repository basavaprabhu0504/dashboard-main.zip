import { useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, RefreshCw, StopCircle, PlayCircle, Send, Terminal, CheckCircle2 } from 'lucide-react';
import { useVpnStatus } from '../hooks/useVpnStatus';

export default function VPNConfiguration() {
  const { status, actionLoading, chatLoading, chatOutput, message, startClassicalVpn, stopClassicalVpn, sendSocketMessage } = useVpnStatus();
  const [inputMessage, setInputMessage] = useState('Hello from Client');

  const handleSend = (e) => {
    e.preventDefault();
    if (inputMessage.trim()) {
      sendSocketMessage(inputMessage.trim());
    }
  };

  return (
    <div className="space-y-6">
      {message && (
        <div className={`rounded-2xl border p-4 text-sm flex items-center justify-between ${
          message.type === 'success' ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300' :
          message.type === 'error' ? 'border-rose-500/40 bg-rose-500/10 text-rose-300' :
          'border-cyan-500/40 bg-cyan-500/10 text-cyan-300'
        }`}>
          <span>{message.text}</span>
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-2">
        {/* Classical OpenVPN Card */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">Classical OpenVPN</h2>
              <p className="text-sm text-slate-400">AES-256-GCM Tunnel • Ubuntu VMs</p>
            </div>
            <div className={`rounded-full px-3 py-1 text-sm font-medium ${status.vpnState === 'CONNECTED' ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30' : status.vpnState === 'STATUS_UNKNOWN' || status.vpnState === 'ERROR' ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30' : 'bg-rose-500/10 text-rose-300 border border-rose-500/30'}`}>
              {status.vpnState}
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <button
              onClick={startClassicalVpn}
              disabled={status.vpnState === 'CONNECTED' || actionLoading}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition ${
                status.vpnState === 'CONNECTED'
                  ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
              }`}
            >
              {actionLoading && status.vpnState === 'CONNECTING' ? (
                <>
                  <RefreshCw size={16} className="animate-spin" />
                  CONNECTING...
                </>
              ) : (
                <>
                  <PlayCircle size={16} />
                  CLASSICAL VPN
                </>
              )}
            </button>

            <button
              onClick={stopClassicalVpn}
              disabled={status.vpnState === 'DISCONNECTED' || status.vpnState === 'IDLE' || actionLoading}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition ${
                status.vpnState === 'DISCONNECTED' || status.vpnState === 'IDLE'
                  ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/40 hover:bg-rose-500/30'
              }`}
            >
              {actionLoading && status.vpnState === 'DISCONNECTING' ? (
                <>
                  <RefreshCw size={16} className="animate-spin" />
                  DISCONNECTING...
                </>
              ) : (
                <>
                  <StopCircle size={16} />
                  DISCONNECT CLASSICAL VPN
                </>
              )}
            </button>
          </div>

          <div className="mt-6 grid gap-3 text-sm text-slate-300 border-t border-slate-800 pt-4">
            <div className="flex justify-between"><span>Server</span><span className={status.serverActive ? 'text-emerald-300' : 'text-slate-400'}>{status.serverActive ? 'Connected' : status.serverOnline ? 'Disconnected' : 'Status Unknown'}</span></div>
            <div className="flex justify-between"><span>Client</span><span className={status.clientActive ? 'text-emerald-300' : 'text-slate-400'}>{status.clientActive ? 'Connected' : status.clientOnline ? 'Disconnected' : 'Status Unknown'}</span></div>
            <div className="flex justify-between"><span>Mode</span><span className="font-mono text-cyan-400">CLASSICAL</span></div>
            {status.service && <div className="flex justify-between"><span>Service</span><span className="text-slate-100">{status.service}</span></div>}
          </div>
        </motion.div>

        {/* Post-Quantum VPN Card */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">Post-Quantum VPN</h2>
              <p className="text-sm text-slate-400">Coming Soon</p>
            </div>
            <div className="rounded-full bg-cyan-500/10 px-3 py-1 text-sm font-medium text-cyan-300 border border-cyan-500/30">
              COMING SOON
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <button disabled className="rounded-xl border border-slate-700 bg-slate-800/70 px-4 py-2.5 text-sm text-slate-500 cursor-not-allowed">
              Post-Quantum VPN Coming Soon
            </button>
            <button disabled className="rounded-xl border border-slate-700 bg-slate-800/70 px-4 py-2.5 text-sm text-slate-500 cursor-not-allowed">
              Integration Unavailable
            </button>
          </div>

          <div className="mt-6 grid gap-3 text-sm text-slate-300 border-t border-slate-800 pt-4">
            <p className="text-slate-400">Post-Quantum VPN integration is not yet available. No connection status or performance data is being simulated.</p>
          </div>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }} className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold">Hybrid VPN</h2>
            <p className="text-sm text-slate-400">Coming Soon</p>
          </div>
          <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-3 py-1 text-sm font-medium text-cyan-300">COMING SOON</span>
        </div>
        <button disabled className="mt-6 rounded-xl border border-slate-700 bg-slate-800/70 px-4 py-2.5 text-sm text-slate-500 cursor-not-allowed">Hybrid VPN integration unavailable</button>
      </motion.div>

      {/* Socket Chat & Command Output Terminal */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Terminal className="text-cyan-400" size={20} />
              <h2 className="text-xl font-semibold">Python Socket Chat Terminal Output</h2>
            </div>
            <p className="text-sm text-slate-400 mt-1">Send hello socket payload from Client VM → Server VM over OpenVPN tunnel (`10.8.0.1:9999`) and capture response</p>
          </div>

          <form onSubmit={handleSend} className="flex gap-2 w-full sm:w-auto">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Type client payload..."
              className="rounded-xl border border-slate-700 bg-slate-950 px-4 py-2 text-sm text-slate-100 placeholder-slate-500 outline-none focus:border-cyan-400 flex-1 sm:w-64"
            />
            <button
              type="submit"
              disabled={chatLoading}
              className="flex items-center gap-2 rounded-xl border border-cyan-500/40 bg-cyan-500/20 px-4 py-2 text-sm font-medium text-cyan-300 transition hover:bg-cyan-500/30 disabled:opacity-50"
            >
              {chatLoading ? <RefreshCw size={16} className="animate-spin" /> : <Send size={16} />}
              Send Message
            </button>
          </form>
        </div>

        {/* Highlighted Response or Error */}
        {chatOutput?.success && chatOutput?.serverResponse && (
          <div className="mt-6 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-emerald-300">
            <div className="flex items-center gap-2 font-medium text-sm">
              <CheckCircle2 size={18} className="text-emerald-400" />
              Server Response Received on Frontend:
            </div>
            <p className="mt-2 text-sm font-mono text-slate-100 bg-slate-950/60 p-3 rounded-xl border border-emerald-500/20 break-all">
              {chatOutput.serverResponse}
            </p>
          </div>
        )}

        {chatOutput?.success === false && (
          <div className="mt-6 rounded-2xl border border-rose-500/30 bg-rose-500/10 p-4 text-rose-300">
            <div className="flex items-center gap-2 font-medium text-sm">
              <Terminal className="text-rose-400" size={18} />
              Message not passed over VPN tunnel:
            </div>
            <div className="mt-2 text-sm font-mono text-slate-100 bg-slate-950/60 p-3 rounded-xl border border-rose-500/20">
              {chatOutput.message || 'The Ubuntu VMs are not online, so the message could not be delivered.'}
            </div>
          </div>
        )}

        {/* Live Command Terminal Output */}
        <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-950 p-4 font-mono text-xs text-slate-300">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-3 text-slate-500">
            <span>Terminal Output (socket exchange logs)</span>
            <span>TCP / IP 10.8.0.1:9999</span>
          </div>

          {chatLoading ? (
            <div className="py-6 text-center text-cyan-400 flex items-center justify-center gap-2">
              <RefreshCw size={16} className="animate-spin" />
              Executing socket connection from Client VM to Server VM over VPN tunnel...
            </div>
          ) : chatOutput?.terminalLogs ? (
            <div className="space-y-2">
              {chatOutput.terminalLogs.map((logLine, index) => (
                <div key={index} className="flex gap-2">
                  <span className="text-cyan-400">$</span>
                  <span className={logLine.includes('Received Response') ? 'text-emerald-300 font-bold' : logLine.includes('Sent:') ? 'text-cyan-300' : 'text-slate-300'}>
                    {logLine}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-4 text-slate-500 text-center">
              Click <strong className="text-cyan-300">"Send Message"</strong> above to execute a socket chat request from Client VM to Server VM and display live response terminal output here.
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
