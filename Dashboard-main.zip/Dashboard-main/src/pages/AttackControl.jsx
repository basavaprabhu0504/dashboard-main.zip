import { motion } from 'framer-motion';
import { AlertTriangle, PauseCircle, PlayCircle, RefreshCw, ShieldAlert, StopCircle } from 'lucide-react';
import { mockData } from '../services/mockData';

export default function AttackControl() {
  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-amber-500/20 bg-amber-500/10 p-4 text-amber-300">
        <div className="flex items-center gap-2 font-medium">
          <AlertTriangle size={16} /> Only use inside controlled lab environments.
        </div>
      </div>
      <div className="grid gap-6 xl:grid-cols-[1fr_0.7fr]">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
          <h2 className="text-xl font-semibold">Attack Selection</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {mockData.attackOptions.map((attack) => (
              <label key={attack} className="flex items-center gap-2 rounded-2xl border border-slate-800 bg-slate-950/70 px-3 py-3 text-sm text-slate-300">
                <input type="checkbox" className="h-4 w-4 rounded border-slate-600 bg-slate-900" />
                {attack}
              </label>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <button className="rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-2 text-rose-300">Start Attack</button>
            <button className="rounded-2xl border border-amber-500/30 bg-amber-500/10 px-4 py-2 text-amber-300">Pause Attack</button>
            <button className="rounded-2xl border border-slate-700 bg-slate-800/70 px-4 py-2 text-slate-300">Stop Attack</button>
            <button className="rounded-2xl border border-cyan-500/30 bg-cyan-500/10 px-4 py-2 text-cyan-300">Reset</button>
            <button className="rounded-2xl border border-rose-500/40 bg-rose-500/20 px-4 py-2 font-semibold text-rose-300">Emergency Stop</button>
          </div>
        </div>
        <motion.div initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
          <h2 className="text-xl font-semibold">Current Attack</h2>
          <div className="mt-5 space-y-4 text-sm">
            <div className="flex justify-between"><span>Attack Target</span><span className="text-slate-100">VPN Server VM</span></div>
            <div className="flex justify-between"><span>Elapsed Time</span><span className="text-slate-100">00:03:11</span></div>
            <div className="flex justify-between"><span>Attack Status</span><span className="text-amber-300">Running</span></div>
            <div className="flex justify-between"><span>Packets Modified</span><span className="text-slate-100">128</span></div>
            <div className="flex justify-between"><span>Detection Status</span><span className="text-emerald-300">Detected</span></div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
