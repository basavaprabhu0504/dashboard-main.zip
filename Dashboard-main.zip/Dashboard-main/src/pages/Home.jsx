import { motion } from 'framer-motion';
import { Activity, ArrowRight, FileText, ShieldAlert, TerminalSquare, RefreshCw } from 'lucide-react';
import StatusCard from '../components/common/StatusCard';
import { mockData } from '../services/mockData';
import { useVpnStatus } from '../hooks/useVpnStatus';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const { status, loading, startClassicalVpn, actionLoading, message } = useVpnStatus();
  const navigate = useNavigate();

  const liveStats = [
    { label: 'VPN Status', value: status.vpnRunning ? 'Running' : 'Stopped', change: status.vpnRunning ? 'Active Tunnel' : 'Disconnected', tone: status.vpnRunning ? 'green' : 'red' },
    { label: 'Tunnel IP', value: status.tunnelIP, change: 'Server Tunnel Interface', tone: 'blue' },
    { label: 'Connected Client', value: status.connectedClient, change: 'Client Tunnel IP', tone: 'cyan' },
    { label: 'Current Cipher', value: status.cipher, change: 'Encryption Standard', tone: 'purple' },
    { label: 'Tunnel Uptime', value: status.uptime, change: 'Active Duration', tone: 'yellow' },
    { label: 'VM Reachability', value: status.serverOnline && status.clientOnline ? 'Both Online' : status.serverOnline ? 'Server Only' : status.clientOnline ? 'Client Only' : 'VMs Offline', change: 'SSH Status', tone: status.serverOnline && status.clientOnline ? 'green' : 'amber' },
  ];

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-3xl border border-slate-800 bg-gradient-to-br from-cyan-500/10 via-slate-900 to-slate-950 p-6 shadow-panel">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm uppercase tracking-[0.3em] text-cyan-400">Mission Control Center</p>
            <h1 className="mt-2 text-3xl font-semibold sm:text-4xl">{mockData.project.name}</h1>
            <p className="mt-3 max-w-2xl text-sm text-slate-300 sm:text-base">{mockData.project.description}</p>
            <div className="mt-5 flex flex-wrap gap-3 text-sm">
              <span className="rounded-full border border-cyan-500/30 bg-cyan-500/10 px-3 py-1 text-cyan-300">Team: {mockData.project.team.join(', ')}</span>
              <span className="rounded-full border border-slate-700 px-3 py-1 text-slate-300">Guide: {mockData.project.guide}</span>
            </div>
          </div>
          <div className={`rounded-2xl border ${status.vpnRunning ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300' : 'border-rose-500/30 bg-rose-500/10 text-rose-300'} p-4`}>
            <div className="flex items-center gap-2 text-sm font-medium">
              <Activity size={16} />
              {status.vpnRunning ? 'VPN Tunnel Active' : 'VPN Tunnel Stopped'}
            </div>
            <p className="mt-2 text-sm text-slate-300">Server: {status.serverOnline ? 'Online' : 'Offline'} | Client: {status.clientOnline ? 'Online' : 'Offline'}</p>
          </div>
        </div>
      </motion.div>

      {message && (
        <div className={`rounded-2xl border p-4 text-sm flex items-center justify-between ${message.type === 'success' ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300' : message.type === 'error' ? 'border-rose-500/40 bg-rose-500/10 text-rose-300' : 'border-cyan-500/40 bg-cyan-500/10 text-cyan-300'}`}>
          <span>{message.text}</span>
          <button onClick={() => navigate('/vpn')} className="underline ml-4">View VPN Page</button>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {liveStats.map((stat) => (
          <StatusCard key={stat.label} title={stat.label} value={stat.value} subtitle={stat.change} tone={stat.tone} />
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">Recent Activity</h2>
              <p className="text-sm text-slate-400">Live experiment events from the lab control center</p>
            </div>
            <div className={`rounded-full border px-3 py-1 text-sm ${status.vpnRunning ? 'border-cyan-500/30 bg-cyan-500/10 text-cyan-300' : 'border-slate-700 bg-slate-800 text-slate-400'}`}>
              VPN {status.vpnRunning ? 'RUNNING' : 'STOPPED'}
            </div>
          </div>
          <div className="mt-6 space-y-4">
            {mockData.timeline.map((item) => (
              <div key={item.title} className="flex items-start gap-3">
                <div className={`mt-1 h-3 w-3 rounded-full ${item.color === 'green' ? 'bg-emerald-400' : item.color === 'red' ? 'bg-rose-400' : item.color === 'blue' ? 'bg-cyan-400' : 'bg-amber-400'}`} />
                <div className="flex-1 border-b border-slate-800 pb-3">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{item.title}</p>
                    <p className="text-sm text-slate-400">{item.time}</p>
                  </div>
                  <p className="mt-1 text-sm text-slate-400">{item.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
            <h2 className="text-xl font-semibold">Quick Actions</h2>
            <div className="mt-4 grid gap-3">
              <button 
                onClick={startClassicalVpn} 
                disabled={actionLoading || status.vpnRunning}
                className={`flex items-center justify-between rounded-2xl border border-cyan-500/30 bg-cyan-500/10 px-4 py-3 text-left text-cyan-300 transition hover:bg-cyan-500/20 disabled:opacity-50`}
              >
                <span className="flex items-center gap-2">
                  {actionLoading ? <RefreshCw size={16} className="animate-spin" /> : <TerminalSquare size={16} />}
                  {status.vpnRunning ? 'VPN Running' : 'Start Classical VPN'}
                </span>
                <ArrowRight size={16} />
              </button>
              <button 
                onClick={() => navigate('/vpn')} 
                className="flex items-center justify-between rounded-2xl border border-slate-700 bg-slate-800/70 px-4 py-3 text-left text-slate-200 transition hover:border-cyan-400"
              >
                <span className="flex items-center gap-2"><FileText size={16} />VPN Control Center</span>
                <ArrowRight size={16} />
              </button>
              <button 
                onClick={() => navigate('/logs')} 
                className="flex items-center justify-between rounded-2xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-left text-amber-300 transition hover:bg-amber-500/20"
              >
                <span className="flex items-center gap-2"><ShieldAlert size={16} />Open Logs</span>
                <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
