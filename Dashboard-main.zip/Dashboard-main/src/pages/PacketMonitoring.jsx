import { motion } from 'framer-motion';
import StatusCard from '../components/common/StatusCard';
import LineChartCard from '../components/charts/LineChartCard';
import PieChartCard from '../components/charts/PieChartCard';
import BasicTable from '../components/tables/BasicTable';
import { useMetrics } from '../hooks/useMetrics';
import { mockData } from '../services/mockData';

export default function PacketMonitoring() {
  const { packetsData } = useMetrics();

  const totalCaptured = packetsData?.packetCount || mockData.packets.captured;
  const latest = packetsData?.latestPacket;

  const packetStats = [
    { title: 'Packets Captured', value: totalCaptured.toLocaleString(), subtitle: 'Live tcpdump tun0', tone: 'blue' },
    { title: 'Latest Source IP', value: latest?.source || '10.8.0.2', subtitle: 'Connected Client', tone: 'cyan' },
    { title: 'Destination IP', value: latest?.destination || '10.8.0.1', subtitle: 'VPN Server', tone: 'green' },
    { title: 'Latest Protocol', value: latest?.protocol || 'UDP', subtitle: 'Transport Protocol', tone: 'purple' },
    { title: 'Packet Size', value: latest?.size || '84 B', subtitle: 'Captured Frame', tone: 'yellow' },
    { title: 'Tunnel Status', value: latest ? 'Active Stream' : 'Monitoring', subtitle: 'Encrypted tun0', tone: 'green' },
  ];

  const recentPacketsList = packetsData?.recentPackets || mockData.packets.recentPackets;

  const rows = recentPacketsList.map((p) => [
    p.time || '14:00:00',
    p.source || '10.8.0.2',
    p.destination || '10.8.0.1',
    p.protocol || 'UDP',
    p.status || 'Encrypted',
    p.size || '84 B'
  ]);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {packetStats.map((stat) => (
          <StatusCard key={stat.title} title={stat.title} value={stat.value} subtitle={stat.subtitle} tone={stat.tone} />
        ))}
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <LineChartCard title="Live Packet Flow (packets/sec)" data={mockData.packets.liveFlow} color="#22c55e" />
        <LineChartCard title="Traffic Timeline" data={mockData.packets.trafficTimeline} color="#38bdf8" />
      </div>

      <div className="grid gap-6 xl:grid-cols-[0.7fr_1.3fr]">
        <PieChartCard title="Protocol Distribution" data={mockData.packets.packetTypes} />
        <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-4 shadow-panel">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-lg font-semibold">Live Captured Packets (tcpdump tun0)</h3>
            <div className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-sm text-emerald-300 animate-pulse">
              Live (1s poll)
            </div>
          </div>
          <BasicTable headers={['Timestamp', 'Source', 'Destination', 'Protocol', 'Status', 'Packet Size']} rows={rows} />
        </div>
      </div>
    </div>
  );
}
