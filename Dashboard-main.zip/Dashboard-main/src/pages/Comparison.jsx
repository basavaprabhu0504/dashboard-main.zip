import { motion } from 'framer-motion';
import { Radar } from 'react-chartjs-2';
import { Chart as ChartJS, RadialLinearScale, PointElement, LineElement, Filler } from 'chart.js';
import { mockData } from '../services/mockData';

ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler);

export default function Comparison() {
  const comparisonData = {
    labels: ['Security', 'Performance', 'Scalability', 'Compatibility', 'Reliability'],
    datasets: [
      {
        label: 'Classical VPN',
        data: [50, 55, 70, 95, 60],
        backgroundColor: 'rgba(56, 189, 248, 0.2)',
        borderColor: '#38bdf8',
      },
      {
        label: 'PQ VPN',
        data: [85, 80, 75, 70, 82],
        backgroundColor: 'rgba(34, 197, 94, 0.2)',
        borderColor: '#22c55e',
      },
      {
        label: 'Hybrid VPN',
        data: [95, 90, 88, 80, 92],
        backgroundColor: 'rgba(168, 85, 247, 0.2)',
        borderColor: '#a855f7',
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
        <h2 className="text-xl font-semibold">Implementation Comparison</h2>
        <div className="mt-4 overflow-hidden rounded-2xl border border-slate-800">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-800/80 text-left text-slate-300">
              <tr>
                <th className="px-4 py-3">Metric</th>
                <th className="px-4 py-3">Classical VPN</th>
                <th className="px-4 py-3">PQ VPN</th>
                <th className="px-4 py-3">Hybrid VPN</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['Handshake Time', `${mockData.comparison.classical.handshake} ms`, `${mockData.comparison.pq.handshake} ms`, `${mockData.comparison.hybrid.handshake} ms`],
                ['CPU Usage', `${mockData.comparison.classical.cpu}%`, `${mockData.comparison.pq.cpu}%`, `${mockData.comparison.hybrid.cpu}%`],
                ['Memory Usage', `${mockData.comparison.classical.memory}%`, `${mockData.comparison.pq.memory}%`, `${mockData.comparison.hybrid.memory}%`],
                ['Bandwidth', `${mockData.comparison.classical.bandwidth} Mbps`, `${mockData.comparison.pq.bandwidth} Mbps`, `${mockData.comparison.hybrid.bandwidth} Mbps`],
                ['Latency', `${mockData.comparison.classical.latency} ms`, `${mockData.comparison.pq.latency} ms`, `${mockData.comparison.hybrid.latency} ms`],
                ['Replay Protection', mockData.comparison.classical.replay, mockData.comparison.pq.replay, mockData.comparison.hybrid.replay],
                ['Downgrade Protection', mockData.comparison.classical.downgrade, mockData.comparison.pq.downgrade, mockData.comparison.hybrid.downgrade],
                ['MITM Detection', mockData.comparison.classical.mitm, mockData.comparison.pq.mitm, mockData.comparison.hybrid.mitm],
                ['Negotiation Security', mockData.comparison.classical.negotiation, mockData.comparison.pq.negotiation, mockData.comparison.hybrid.negotiation],
                ['Encryption Algorithm', mockData.comparison.classical.algorithm, mockData.comparison.pq.algorithm, mockData.comparison.hybrid.algorithm],
              ].map((row) => (
                <tr key={row[0]} className="border-t border-slate-800/80">
                  <td className="px-4 py-3 text-slate-300">{row[0]}</td>
                  <td className="px-4 py-3 text-slate-200">{row[1]}</td>
                  <td className="px-4 py-3 text-slate-200">{row[2]}</td>
                  <td className="px-4 py-3 text-slate-200">{row[3]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="rounded-3xl border border-slate-800 bg-slate-900/70 p-6 shadow-panel">
        <h2 className="text-xl font-semibold">Security Radar</h2>
        <div className="mt-4 max-w-2xl">
          <Radar data={comparisonData} options={{ responsive: true }} />
        </div>
      </div>
    </div>
  );
}
