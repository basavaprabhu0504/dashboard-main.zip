import { useState, useEffect, useCallback } from 'react';
import { api } from '../services/api';
import { getAgentAvailability, getVpnStatusSummary, startClassicalVPN, stopClassicalVPN } from '../services/vpnService';

const initialStatus = {
  serverOnline: false, clientOnline: false, serverActive: false, clientActive: false,
  vpnRunning: false, vpnState: 'IDLE', tunnelIP: 'Unknown', connectedClient: 'Unknown',
  cipher: 'Not reported by agent', uptime: 'Not reported by agent', service: null, serverHost: null, clientHost: null,
};

export function useVpnStatus() {
  const [status, setStatus] = useState(initialStatus);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [chatLoading, setChatLoading] = useState(false);
  const [chatOutput, setChatOutput] = useState(null);
  const [message, setMessage] = useState(null);

  const applySummary = useCallback((summary, availability = {}) => {
    setStatus((current) => ({ ...current, ...availability, serverActive: summary.serverActive,
      clientActive: summary.clientActive, vpnRunning: summary.serverActive && summary.clientActive,
      vpnState: summary.state, service: summary.service || summary.server?.service || summary.client?.service || null,
      serverHost: summary.serverHost || current.serverHost, clientHost: summary.clientHost || current.clientHost }));
  }, []);

  const fetchStatus = useCallback(async () => {
    try {
      const summary = await getVpnStatusSummary();
      applySummary(summary, { serverOnline: summary.serverOnline, clientOnline: summary.clientOnline });
      return summary;
    } catch (error) {
      const summary = { serverActive: false, clientActive: false, state: 'STATUS_UNKNOWN', errors: [error.message] };
      applySummary(summary, { serverOnline: false, clientOnline: false });
      return summary;
    } finally {
      setLoading(false);
    }
  }, [applySummary]);

  useEffect(() => {
    const poll = () => !document.hidden && fetchStatus();
    poll();
    const interval = setInterval(poll, 5000);
    document.addEventListener('visibilitychange', poll);
    return () => { clearInterval(interval); document.removeEventListener('visibilitychange', poll); };
  }, [fetchStatus]);

  const startClassicalVpn = async () => {
    if (actionLoading) return;
    setActionLoading(true);
    setStatus((current) => ({ ...current, vpnState: 'CONNECTING' }));
    setMessage({ type: 'info', text: 'Starting QVPN server, then QVPN client...' });
    try {
      const { status: summary } = await startClassicalVPN();
      applySummary(summary);
      if (summary.state === 'CONNECTED') setMessage({ type: 'success', text: 'Classical VPN connected.' });
      else if (summary.state === 'STATUS_UNKNOWN') setMessage({ type: 'error', text: 'VPN services started, but tunnel status could not be confirmed.' });
      else setMessage({ type: 'error', text: 'VPN services started, but the connection is incomplete.' });
    } catch (error) {
      setStatus((current) => ({ ...current, vpnState: 'ERROR', vpnRunning: false }));
      setMessage({ type: 'error', text: error.message || 'Unable to start QVPN server.' });
    } finally {
      setActionLoading(false);
      fetchStatus();
    }
  };

  const stopClassicalVpn = async () => {
    if (actionLoading) return;
    setActionLoading(true);
    setStatus((current) => ({ ...current, vpnState: 'DISCONNECTING' }));
    setMessage({ type: 'info', text: 'Stopping QVPN client, then QVPN server...' });
    try {
      const { status: summary } = await stopClassicalVPN();
      applySummary(summary);
      setMessage({ type: summary.state === 'DISCONNECTED' ? 'success' : 'error', text: summary.state === 'DISCONNECTED' ? 'Classical VPN disconnected.' : 'VPN stop requests completed, but final status could not be confirmed.' });
    } catch (error) {
      setStatus((current) => ({ ...current, vpnState: 'ERROR' }));
      setMessage({ type: 'error', text: error.message || 'VPN cleanup was incomplete.' });
    } finally {
      setActionLoading(false);
      fetchStatus();
    }
  };

  // Socket chat remains on the existing dashboard backend; it is not part of the VM control-agent API.
  const sendSocketMessage = async (customMessage = 'Hello from Client') => {
    setChatLoading(true);
    if (!status.vpnRunning) {
      setChatOutput({ success: false, terminalLogs: ['[SYSTEM] VPN connection is not active (STOPPED).', '[SYSTEM] Start the Classical VPN tunnel before sending socket messages.'] });
      setMessage({ type: 'error', text: 'Classical VPN is currently stopped. Start the tunnel before sending a socket message.' });
      setChatLoading(false);
      return;
    }
    const res = await api.post('/chat/start', { message: customMessage });
    const chatData = res?.data || res;
    setChatOutput(chatData || { success: false, message: 'Failed to complete socket chat execution.' });
    setMessage(chatData?.success ? { type: 'success', text: 'Response received from Server VM over VPN tunnel!' } : { type: 'error', text: chatData?.message || 'Message was not passed over the VPN tunnel.' });
    setChatLoading(false);
  };

  return { status, loading, actionLoading, chatLoading, chatOutput, message, setMessage, startClassicalVpn, stopClassicalVpn, sendSocketMessage, refreshStatus: fetchStatus };
}
